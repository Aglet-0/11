<script>
  import BrowserChrome from "./components/BrowserChrome.svelte";
  import Content from "./components/Content.svelte";
  import { closeTab, newTab, ui } from "./lib/tabs.svelte.js";

  function shortcut(event) {
    if (!(event.metaKey || event.ctrlKey)) return;
    const key = event.key.toLowerCase();
    if (key === "t") newTab();
    else if (key === "w") closeTab(ui.activeId);
    else return;
    event.preventDefault();
  }
</script>

<svelte:window onkeydown={shortcut} />

<div id="app">
  <BrowserChrome />
  <Content />
</div>
