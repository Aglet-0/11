<script>
  import MessageCircle from "@lucide/svelte/icons/message-circle";
  import Plus from "@lucide/svelte/icons/plus";
  import Settings from "@lucide/svelte/icons/settings";
  import Sparkles from "@lucide/svelte/icons/sparkles";
  import X from "@lucide/svelte/icons/x";

  import TabList from "./TabList.svelte";
  import UrlBar from "./UrlBar.svelte";
  import { chat } from "../lib/chat.svelte.js";
  import { openAiTab, openInternal, closeTab, focus, newTab, tabs, ui } from "../lib/tabs.svelte.js";
  import { checkAiEnabled, aiStatus } from "../lib/ai.svelte.js";

  $effect(() => { checkAiEnabled(); });

  const internalIcon = (kind) => kind === "settings" ? Settings : kind === "chat" ? MessageCircle : Sparkles;
</script>

<header id="browserChrome">
  <div id="tabStrip">
    {#each tabs as tab (tab.id)}
      {@const Icon = internalIcon(tab.kind)}
      <button
        class="chromeTab"
        class:active={tab.id === ui.activeId}
        onclick={() => focus(tab.id)}
        title={tab.title}
      >
        <span class="chromeTabIcon">
          {#if tab.favicon}
            <img src={tab.favicon} alt="" draggable="false" />
          {:else}
            <Icon />
          {/if}
        </span>
        <span class="chromeTabTitle">{tab.title}</span>
        <span
          class="chromeTabClose"
          role="button"
          tabindex="0"
          aria-label="Close tab"
          onclick={(event) => { event.stopPropagation(); closeTab(tab.id); }}
          onkeydown={(event) => { if (event.key === "Enter" || event.key === " ") { event.stopPropagation(); closeTab(tab.id); } }}
        ><X /></span>
      </button>
    {/each}
    <button class="newChromeTab" aria-label="New tab" title="New tab" onclick={() => newTab()}><Plus /></button>
  </div>

  <div id="toolbarRow">
    <div id="toolbarBrand" aria-label="GameTFM">G<span>TFM</span></div>
    <UrlBar />
    <div id="toolbarActions">
      {#if !chat.disabled}
        <button class="toolbarBtn" title="Chat" aria-label="Chat" onclick={() => openInternal("chat")}><MessageCircle /></button>
      {/if}
      {#if aiStatus.enabled}
        <button class="toolbarBtn" title="AI" aria-label="AI" onclick={() => openAiTab()}><Sparkles /></button>
      {/if}
      <button class="toolbarBtn" title="Settings" aria-label="Settings" onclick={() => openInternal("settings")}><Settings /></button>
    </div>
  </div>
</header>
